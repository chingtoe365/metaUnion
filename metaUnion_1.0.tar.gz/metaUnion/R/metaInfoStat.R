metaInfoStat <-
function(inputList, metaResult, filterData=TRUE){
	args = list(inputList, metaResult)
	verbose = TRUE

	if(nargs() < 2) {
	  cmd="echo '\n needs: inputList, metaResult'";
	  system(cmd,wait=FALSE);        
	  q();
	}
	rawInputList = inputList
	### Check dimension of expression matrix and annotations
	if(filterData==TRUE){
		inputList = inputExpCheck(inputList)
		print("Data list pre-check finished!")		
	}
	count_raw = {}
	count_filtered = {}
	count_deg = {}
	nbstudies = length(inputList)
	minitable = metaResult[, (nbstudies + 3):(2 * nbstudies + 2)]
	## Input data info
	dataInfoMat = matrix(nrow=nbstudies + 1, ncol=6)
	dataInfoMat = as.data.frame(dataInfoMat)
	rownames(dataInfoMat) = c(names(inputList), "Total")
	colnames(dataInfoMat) = c("Study", "EntrezGene", "Case", "Control", "Sum", "Number of DEGs found")
	uniq_genes = unique(unlist(lapply(rawInputList, function(x){x[[1]][, ncol(x[[1]])-1]})))
	DEGs_entrez = metaResult[metaResult$metaPvalBonf < 0.05, 1]
	studyCount_raw = unlist(apply(minitable, 1, function(y) sum(!is.na(y))))
	degInStudyCount_raw = unlist(apply(minitable[match(DEGs_entrez, metaResult[, 1]), ], 1, function(y) sum(!is.na(y))))
	# uniq_genes_filtered = unique(unlist(lapply(inputList, function(x){x[[1]][, ncol(x[[1]])-1]})))
	# studyCount_raw = lapply(uniq_genes, function(x){
		# sum(sapply(1:nbstudies, function(y){
			# !is.na(match(x, rawInputList[[y]][[1]][, ncol(rawInputList[[y]][[1]]) - 1]))
		# }))
	# })
	# studyCount_filtered = lapply(uniq_genes_filtered, function(x){
		# sum(sapply(1:nbstudies, function(y){
			# !is.na(match(x, inputList[[y]][[1]][, ncol(inputList[[y]][[1]]) - 1]))
		# }))
	# })
	# DEGs_entrez = metaResult[metaResult$metaPvalBonf < 0.05, 1]
	# degInStudyCount_raw = lapply(DEGs_entrez, function(x){
		# sum(sapply(1:nbstudies, function(y){
			# !is.na(match(x, rawInputList[[y]][[1]][, ncol(rawInputList[[y]][[1]]) - 1]))
		# }))
	# })
	for(i in 1:nbstudies){
		dataInfoMat[i, 1] = names(inputList)[i] 
		dataInfoMat[i, 2] = nrow(inputList[[i]][[1]]) 
		dataInfoMat[i, 3] = inputList[[i]][[2]][1] 
		dataInfoMat[i, 4] = inputList[[i]][[2]][2] 
		dataInfoMat[i, 5] = sum(inputList[[i]][[2]]) 
		# dataInfoMat[i, 6] = apply(minitable, 2, function(x) {
			# sum(x[!is.na(x)] < 0.05)
		# })
		count_raw = c(count_raw, sum(studyCount_raw==i))
		# count_filtered = c(count_filtered, sum(studyCount_filtered==i))
		count_deg = c(count_deg, sum(degInStudyCount_raw==i))
	}
	dataInfoMat[nrow(dataInfoMat), 1] = nbstudies
	dataInfoMat[nrow(dataInfoMat), 2] = nrow(metaResult)
	dataInfoMat[nrow(dataInfoMat), 3] = sum(dataInfoMat[1:nbstudies, 3])
	dataInfoMat[nrow(dataInfoMat), 4] = sum(dataInfoMat[1:nbstudies, 4])
	dataInfoMat[nrow(dataInfoMat), 5] = sum(dataInfoMat[1:nbstudies, 5])
	# dataInfoMat[nrow(dataInfoMat), 6] = NA
	dataInfoMat[, 6] = c(apply(minitable, 2, function(x) {
			sum(x[!is.na(x)] < 0.05)
		}), NA)
	ratio_raw = paste(round(count_raw / sum(count_raw), 2) * 100, "%", sep="")
	ratio_deg = paste(round(count_deg / sum(count_deg), 2) * 100, "%", sep="")
	metaInfoMat = data.frame(count_raw, ratio_raw, count_deg, ratio_deg)
	rownames(metaInfoMat) = paste("Found in", 1:nbstudies, "study", sep=" ")
	colnames(metaInfoMat) = c("In initial gene pool", "Percentage (in initial pool)", "In DEGs", "Percentage (in DEGs)")
	returnObj = list(dataInfoMat, metaInfoMat)
	names(returnObj) = c("dataInfoMat", "metaInfoMat")
	return(returnObj)
}
