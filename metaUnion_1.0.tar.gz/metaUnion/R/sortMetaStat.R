sortMetaStat <-
function(metaResult, displayNumber, decreasing=FALSE){
	# args = list(metaResult, sortStat, displayNumber)
	args = list(metaResult, displayNumber)
	verbose = TRUE

	if(nargs() < 2) {
	  stop('needs: metaResult displayNumber');
	}
	
	if((displayNumber < 1) | (displayNumber > nrow(metaResult))){
	  stop("Display number out of boundary(<1 or >nrow(metaResult))")
	}
	# chosenRowInd = order(abs(metaResult[, sortStat]), decreasing=decreasing)[1:displayNumber]
	chosenRowInd = order(abs(metaResult[, "metaPvalBonf"]), -abs(metaResult[, "metaZscore"]), decreasing=decreasing)[1:displayNumber]
	chosenColInd = c("Entrez.Gene", "Symbol", "metaZscore", "metaPval", "effect", "significance", "metaPvalBonf")
	sorted.result = metaResult[chosenRowInd, chosenColInd]
	return(sorted.result)
}
