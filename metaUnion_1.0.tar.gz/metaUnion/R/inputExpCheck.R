inputExpCheck <-
function(inputList){
	# check if input expression matrix dimension match with sample information vector
	judge = unlist(lapply(inputList, function(x){
		return(ncol(x[[1]]) == (sum(x[[2]]) + 2))
	}))
	if(any(!judge)){
		stop("Number of columns in expression does not equal to sum(sample information vector) + 2")
	}
	checkEntrezIDColExist = unlist(lapply(inputList, function(x) any(colnames(x[[1]])=="Entrez.Gene")))
	if(!all(colnames(checkEntrezIDColExist))){
		stop("Column 'Entrez.Gene' not found in expression matrices of some studies")
	}
	# define acceptable characters that coould possibly appear in gene symbol
	# pass_chars = c(letters, toupper(letters), "-")
	pass_chars = as.character(0:9)
	
	# filter probesets without annotation or multiple annotation
	trimVec = lapply(inputList, function(x){
			entrezID = as.character(unlist(x[[1]][ncol(x[[1]]) - 1]))
			# turn null values into "!" to avoid error
			entrezID[which(is.na(entrezID)==TRUE)] = "!"
			# split each entry of gene symbol into string of characters, 
			# match if each character in the pass_chars,
			# if there are any character not matching pass_chars, trim this probeset
			holdem_vec = sapply(entrezID, function(y){
				any(is.na(match(strsplit(y, "")[[1]], pass_chars)))
			})
			if(any(holdem_vec)){
				probeIndToBeTrimmed = which(holdem_vec)
			}else{
				probeIndToBeTrimmed = NA
			}
			print("Wrongly formated probesets removed.")
			##check probesets which expressed in less than 2 samples in each group and filter them out
			
			caseNum <<- as.numeric(x[[2]][1])
			controlNum <<- as.numeric(x[[2]][2])
			count <<- 1
			apply(x[[1]], 1, function(z) {
					case.exp = z[1:caseNum]
					ctr.exp = z[(caseNum + 1):(caseNum + controlNum)]
					condition = (sum(!is.na(case.exp))<2) | (sum(!is.na(ctr.exp))<2)
					if(condition){
						probeIndToBeTrimmed <<- c(probeIndToBeTrimmed, count)
					}
			})
			probeIndToBeTrimmed = unique(na.omit(probeIndToBeTrimmed))
			if(length(probeIndToBeTrimmed)==0){
				probeIndToBeTrimmed = NA
			}
			print("Frquently absent probesets removed.")
			######Old version ######
			# comma = grep(",", gene_symbols)
			# semicolon = grep(";", gene_symbols)
			# space = grep(" ", gene_symbols)
			# # slashes = grep(" ", gene_symbols)
			# nulls = which(is.na(gene_symbols)==TRUE)
			# if(length(c(comma, semicolon, space, nulls))==0){
				# return(NA)
			# }else{
				# probeIndToBeTrimmed = unique(comma, semicolon, space, nulls)
			# }		
		})
	for(i in 1:length(inputList)){
		if(!all(is.na(trimVec[[i]]))){
			inputList[[i]][[1]] = inputList[[i]][[1]][trimVec[[i]], ]
		}
	}
	print("Probes with NA & Multi annotation removed!")
	return(inputList)
}
