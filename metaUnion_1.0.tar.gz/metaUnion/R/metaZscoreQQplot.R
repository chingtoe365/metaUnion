metaZscoreQQplot <-
function(metaResult, mainTitle, savefile, width=500, height=500){
	args = list(metaResult, mainTitle, savefile)
	verbose = TRUE

	if(nargs() < 3) {
	  cmd="echo '\n needs: metaResult mainTitle savefile width=500 height=500 adjustedP=FALSE'";
	  system(cmd,wait=FALSE);        
	  q();
	}
	jpeg(savefile, width=width, height=height, bg="white")
	qqnorm(metaResult$metaZscore, main=mainTitle, col="red")
	dev.off()
}
